DROP table Auteur
DROP table Livre
CREATE TABLE Auteur (
  id_auteur INTEGER PRIMARY KEY AUTOINCREMENT,
  nom TEXT NOT NULL,
  prenom TEXT NOT NULL,
  adresse_mail TEXT NOT NULL
);

CREATE TABLE Livre (
  id_livre INTEGER PRIMARY KEY AUTOINCREMENT,
  id_auteur INTEGER NOT NULL,
  titre TEXT NOT NULL,
  FOREIGN KEY (id_auteur) REFERENCES Auteur (id_auteur)
);

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Hugo', 'Victor', 'victor.hugo@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Flaubert', 'Gustave', 'gustave.flaubert@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Camus', 'Albert', 'albert.camus@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Beauvoir', 'Simone de', 'simone.beauvoir@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Proust', 'Marcel', 'marcel.proust@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Sartre', 'Jean-Paul', 'jean-paul.sartre@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Zola', 'Emile', 'emile.zola@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Saint-Exupéry', 'Antoine de', 'antoine.saintexupery@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Sagan', 'Françoise', 'francoise.sagan@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Dumas', 'Alexandre', 'alexandre.dumas@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Duras', 'Marguerite', 'marguerite.duras@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Balzac', 'Honoré de', 'honore.balzac@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Mauriac', 'François', 'francois.mauriac@gmail.com');

INSERT INTO Auteur (nom, prenom, adresse_mail)
VALUES ('Cohen', 'Albert', 'albert.cohen@gmail.com');


INSERT INTO Livre (id_auteur, titre)
VALUES (1, 'Les Misérables');

INSERT INTO Livre (id_auteur, titre)
VALUES (1, 'Notre-Dame de Paris');

INSERT INTO Livre (id_auteur, titre)
VALUES (2, 'Madame Bovary');

INSERT INTO Livre (id_auteur, titre)
VALUES (3, 'La Peste');

INSERT INTO Livre (id_auteur, titre)
VALUES (4, 'Le Deuxième Sexe');

INSERT INTO Livre (id_auteur, titre)
VALUES (5, 'À la recherche du temps perdu');

INSERT INTO Livre (id_auteur, titre)
VALUES (6, 'Les Mots');

INSERT INTO Livre (id_auteur, titre)
VALUES (6, 'Huis clos');

INSERT INTO Livre (id_auteur, titre)
VALUES (7, 'Germinal');

INSERT INTO Livre (id_auteur, titre)
VALUES (8, 'Le Petit Prince');

INSERT INTO Livre (id_auteur, titre)
VALUES (9, 'Bonjour Tristesse');

INSERT INTO Livre (id_auteur, titre)
VALUES (10, 'Les Trois Mousquetaires');

INSERT INTO Livre (id_auteur, titre)
VALUES (11, 'Gigi');