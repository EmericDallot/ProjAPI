import express from 'express';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
// import AuteurDao from './public/script/AuteurDao.js'
// import LivreDAO from './public/script/LivreDAO.js'

const app = express();
const db = new sqlite3.Database('Database1.db');

// Création de la table Auteur si elle n'existe pas
db.run(`CREATE TABLE IF NOT EXISTS Auteur (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nom TEXT,
  prenom TEXT,
  adresse_mail TEXT
)`);
db.run(`CREATE TABLE IF NOT EXISTS Livre (
  id_livre INTEGER PRIMARY KEY AUTOINCREMENT,
  id_auteur INTEGER NOT NULL,
  titre TEXT NOT NULL,
  FOREIGN KEY (id_auteur) REFERENCES Auteur (id_auteur)
)`);


class AuteurDao {
  // Récupère tous les auteurs
  getAll() {
    return new Promise((resolve, reject) => {
      db.all('SELECT * FROM Auteur', (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  // Récupère un auteur par son ID
  getById(id) {
    return new Promise((resolve, reject) => {
      db.get('SELECT * FROM Auteur WHERE id_auteur = ?', [id], (err, row) => {
        if (err) {
          reject(err);
        } else if (row === undefined) {
          reject(new Error(`Auteur with id ${id} not found`));
        } else {
          resolve(row);
        }
      });
    });
  }

  // Crée un nouvel auteur
  create(auteur) {
    return new Promise((resolve, reject) => {
      db.run('INSERT INTO Auteur (nom, prenom, adresse_mail) VALUES (?, ?, ?)',
        [auteur.nom, auteur.prenom, auteur.adresse_mail],
        function(err) {
          if (err) {
            reject(err);
          } else {
            resolve(this.lastID);
          }
        });
    });
  }

  // Met à jour un auteur
  update(auteur) {
    return new Promise((resolve, reject) => {
      db.run('UPDATE Auteur SET nom = ?, prenom = ?, adresse_mail = ? WHERE id_auteur = ?',
        [auteur.nom, auteur.prenom, auteur.adresse_mail, auteur.id],
        function(err) {
          if (err) {
            reject(err);
          } else if (this.changes === 0) {
            reject(new Error(`Auteur with id ${auteur.id} not found`));
          } else {
            resolve();
          }
        });
    });
  }

  // Supprime un auteur par son ID
  delete(id) {
    return new Promise((resolve, reject) => {
      db.run('DELETE FROM Auteur WHERE id_auteur = ?', [id], function(err) {
        if (err) {
          reject(err);
        } else if (this.changes === 0) {
          reject(new Error(`Auteur with id ${id} not found`));
        } else {
          resolve();
        }
      });
    });
  }
}
class LivreDAO {


  getAll() {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM Livre';
      db.all(sql, [], (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }

  getById(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM Livre WHERE id_livre = ?';
      db.get(sql, [id], (err, row) => {
        if (err) {
          reject(err);
        } else if (row) {
          resolve(row);
        } else {
          reject(new Error(`Livre with id ${id} not found`));
        }
      });
    });
  }

  create(livre) {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO Livre (id_auteur, titre) VALUES (?, ?)';
      db.run(sql, [livre.id_auteur, livre.titre], function (err) {
        if (err) {
          reject(err);
        } else {
          resolve(this.lastID);
        }
      });
    });
  }

  update(livre) {
    return new Promise((resolve, reject) => {
      const sql = 'UPDATE Livre SET id_auteur = ?, titre = ? WHERE id_livre = ?';
      db.run(sql, [livre.id_auteur, livre.titre, livre.id], (err) => {
        if (err) {
          reject(err);
        } else if (this.changes === 0) {
          reject(new Error(`Livre with id ${livre.id} not found`));
        } else {
          resolve();
        }
      });
    });
  }

  delete(id) {
    return new Promise((resolve, reject) => {
      const sql = 'DELETE FROM Livre WHERE id_livre = ?';
      db.run(sql, [id], (err) => {
        if (err) {
          reject(err);
        } else if (this.changes === 0) {
          reject(new Error(`Livre with id ${id} not found`));
        } else {
          resolve();
        }
      });
    });
  }
}


// Création du DAO pour la table Auteur
const auteurDao = new AuteurDao();

const livreDao = new LivreDAO();

// Middleware pour parser les requêtes en JSON
app.use(bodyParser.json());

// Route pour récupérer tous les auteurs
app.get('/auteurs', async (req, res) => {
  try {
    const auteurs = await auteurDao.getAll();
    res.json(auteurs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});


// Route pour récupérer un auteur par ID
app.get('/auteurs/:id', async (req, res) => {
  try {
  const auteur = await auteurDao.getById(req.params.id);
  res.json(auteur);
  } catch (err) {
  res.status(404).json({ error: err.message });
  }
  });
  
  // Route pour créer un nouvel auteur
  app.post('/auteurs', async (req, res) => {
  try {
  const id = await auteurDao.create(req.body);
  res.json({ id });
  } catch (err) {
  res.status(500).json({ error: err.message });
  }
  });
  
  // Route pour mettre à jour un auteur
  app.put('/auteurs/:id', async (req, res) => {
  try {
  await auteurDao.update({ id: req.params.id, ...req.body });
  res.json({ message: 'Auteur updated successfully' });
  } catch (err) {
  res.status(404).json({ error: err.message });
  }
  });
  
  // Route pour supprimer un auteur
  app.delete('/auteurs/:id', async (req, res) => {
  try {
  await auteurDao.delete(req.params.id);
  res.json({ message: 'Auteur deleted successfully' });
  } catch (err) {
  res.status(404).json({ error: err.message });
  }
  });
  
  app.get('/livres', async (req, res) => {
    try {
      const livres = await livreDao.getAll();
      res.json(livres);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  
  // Route pour récupérer un livre par son id
  app.get('/livres/:id', async (req, res) => {
    try {
      const livre = await livreDao.getById(req.params.id);
      res.json(livre);
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });
  
  // Route pour créer un nouveau livre
  app.post('/livres', async (req, res) => {
    try {
      const id = await livreDao.create(req.body);
      res.json({ id });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });
  
  // Route pour mettre à jour un livre
  app.put('/livres/:id', async (req, res) => {
    try {
      await livreDao.update({ id: req.params.id, ...req.body });
      res.json({ message: 'Livre updated successfully' });
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });
  
  // Route pour supprimer un livre
  app.delete('/livres/:id', async (req, res) => {
    try {
      await livreDao.delete(req.params.id);
      res.json({ message: 'Livre deleted successfully' });
    } catch (err) {
      res.status(404).json({ error: err.message });
    }
  });




  // Démarrage du serveur
  app.listen(3000, () => {
  console.log('Server listening on port 3000');
  });
