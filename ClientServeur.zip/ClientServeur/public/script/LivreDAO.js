// import sqlite3 from 'sqlite3';

// class LivreDAO {

//   constructor(dbChemin) {
//     this.db = new sqlite3.Database(dbChemin);
//   }


//   getAll() {
//     return new Promise((resolve, reject) => {
//       const sql = 'SELECT * FROM Livre';
//       this.db.all(sql, [], (err, rows) => {
//         if (err) {
//           reject(err);
//         } else {
//           resolve(rows);
//         }
//       });
//     });
//   }

//   getById(id) {
//     return new Promise((resolve, reject) => {
//       const sql = 'SELECT * FROM Livre WHERE id_livre = ?';
//       this.db.get(sql, [id], (err, row) => {
//         if (err) {
//           reject(err);
//         } else if (row) {
//           resolve(row);
//         } else {
//           reject(new Error(`Livre with id ${id} not found`));
//         }
//       });
//     });
//   }

//   create(livre) {
//     return new Promise((resolve, reject) => {
//       const sql = 'INSERT INTO Livre (id_auteur, titre) VALUES (?, ?)';
//       this.db.run(sql, [livre.id_auteur, livre.titre], function (err) {
//         if (err) {
//           reject(err);
//         } else {
//           resolve(this.lastID);
//         }
//       });
//     });
//   }

//   update(livre) {
//     return new Promise((resolve, reject) => {
//       const sql = 'UPDATE Livre SET id_auteur = ?, titre = ? WHERE id_livre = ?';
//       this.db.run(sql, [livre.id_auteur, livre.titre, livre.id], (err) => {
//         if (err) {
//           reject(err);
//         } else if (this.changes === 0) {
//           reject(new Error(`Livre with id ${livre.id} not found`));
//         } else {
//           resolve();
//         }
//       });
//     });
//   }

//   delete(id) {
//     return new Promise((resolve, reject) => {
//       const sql = 'DELETE FROM Livre WHERE id_livre = ?';
//       this.db.run(sql, [id], (err) => {
//         if (err) {
//           reject(err);
//         } else if (this.changes === 0) {
//           reject(new Error(`Livre with id ${id} not found`));
//         } else {
//           resolve();
//         }
//       });
//     });
//   }
// }

// export default LivreDAO;