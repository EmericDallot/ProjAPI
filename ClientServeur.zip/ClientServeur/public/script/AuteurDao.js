// class AuteurDao {
//     // Récupère tous les auteurs
//     constructor(dbPath) {
//       this.db = new sqlite3.Database(dbPath);
//     }
//     getAll() {
//       return new Promise((resolve, reject) => {
//         this.db.all('SELECT * FROM Auteur', (err, rows) => {
//           if (err) {
//             reject(err);
//           } else {
//             resolve(rows);
//           }
//         });
//       });
//     }
  
//     // Récupère un auteur par son ID
//     getById(id) {
//       return new Promise((resolve, reject) => {
//         this.db.get('SELECT * FROM Auteur WHERE id_auteur = ?', [id], (err, row) => {
//           if (err) {
//             reject(err);
//           } else if (row === undefined) {
//             reject(new Error(`Auteur with id ${id} not found`));
//           } else {
//             resolve(row);
//           }
//         });
//       });
//     }
  
//     // Crée un nouvel auteur
//     create(auteur) {
//       return new Promise((resolve, reject) => {
//         this.db.run('INSERT INTO Auteur (nom, prenom, adresse_mail) VALUES (?, ?, ?)',
//           [auteur.nom, auteur.prenom, auteur.adresse_mail],
//           function(err) {
//             if (err) {
//               reject(err);
//             } else {
//               resolve(this.lastID);
//             }
//           });
//       });
//     }
  
//     // Met à jour un auteur
//     update(auteur) {
//       return new Promise((resolve, reject) => {
//         this.db.run('UPDATE Auteur SET nom = ?, prenom = ?, adresse_mail = ? WHERE id_auteur = ?',
//           [auteur.nom, auteur.prenom, auteur.adresse_mail, auteur.id],
//           function(err) {
//             if (err) {
//               reject(err);
//             } else if (this.changes === 0) {
//               reject(new Error(`Auteur with id ${auteur.id} not found`));
//             } else {
//               resolve();
//             }
//           });
//       });
//     }
  
//     // Supprime un auteur par son ID
//     delete(id) {
//       return new Promise((resolve, reject) => {
//         this.db.run('DELETE FROM Auteur WHERE id_auteur = ?', [id], function(err) {
//           if (err) {
//             reject(err);
//           } else if (this.changes === 0) {
//             reject(new Error(`Auteur with id ${id} not found`));
//           } else {
//             resolve();
//           }
//         });
//       });
//     }
//   }